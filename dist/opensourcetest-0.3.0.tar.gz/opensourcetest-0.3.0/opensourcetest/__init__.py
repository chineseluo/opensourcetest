__version__ = '0.3.0'
__description__ = "We need more free software interface testing."
