#!/user/bin/env python
# -*- coding: utf-8 -*-
from opensourcetest.builtin.assertChecker import AssertChecker


class BaseAssert(AssertChecker):
    ...
