# -*- coding: utf-8 -*-
# !/user/bin/env python
from opensourcetest.builtin.assertScreenShot import AssertScreenShot


class AssertMethod(AssertScreenShot):
    ...
