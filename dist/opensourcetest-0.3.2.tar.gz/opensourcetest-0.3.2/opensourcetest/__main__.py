#!/user/bin/env python
# -*- coding: utf-8 -*-

"""
------------------------------------
@Project : opensourcetest
@Time    : 2021/1/11 14:45
@Auth    : chineseluo
@Email   : 848257135@qq.com
@File    : __main__.py
@IDE     : PyCharm
------------------------------------
"""
from opensourcetest.cli import main

if __name__ == '__main__':
    main()
