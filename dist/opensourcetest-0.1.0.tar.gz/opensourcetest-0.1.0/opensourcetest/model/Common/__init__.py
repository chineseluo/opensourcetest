#!/user/bin/env python
# -*- coding: utf-8 -*-

"""
------------------------------------
@Project : interface_auto_frame
@Time    : 2020/8/25 16:04
@Auth    : chineseluo
@Email   : 848257135@qq.com
@File    : __init__.py
@IDE     : PyCharm
------------------------------------
"""