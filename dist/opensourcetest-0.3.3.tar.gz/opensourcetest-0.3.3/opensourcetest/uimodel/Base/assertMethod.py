# !/user/bin/env python
# -*- coding: utf-8 -*-
import pytest
import logging
from opensourcetest.builtin.assertScreenShot import AssertScreenShot


class AssertMethod(AssertScreenShot):
    ...
